s/icalcluster/icalfileset/g;
s/ICALCLUSTER/ICALFILESET/g;
s/icalstore/icaldirset/g;
s/ICALSTORE/ICALDIRSET/g;
