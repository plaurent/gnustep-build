/* This is just to make the code in the example directory link properly. */
#include <libical/ical.h>

int main()
{

    return 1;
}


void do_something(icalcomponent* comp){
}
